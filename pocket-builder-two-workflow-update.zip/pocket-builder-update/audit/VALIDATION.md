# Validation record

## Scope

Base repository: `YillBrealone/nxnative-pocket-builder` at `ccb42165e20b7c473297cd3d9a1ef91be600d423`.

Both full workflows embed identical copies of `pocket_updates.py` and `test_pocket_updates.py`. The standalone copies here are for review; the workflows do not load them from the repository or from a remote URL.

## Source reconstruction and execution

| Workflow / engine | Result | Applicable checks |
| --- | --- | --- |
| Main / NX2Apple 3739300 | Passed | 9 passed, editor test not applicable |
| Main / Standard 20b59b6 | Passed | 9 passed, editor test not applicable |
| Main / legacy b5ac83d | Passed | 8 passed, editor and new cap tests not applicable |
| Controls / NX2Apple 4ab27a5 | Passed | 10 passed |
| Controls / Standard 20b59b6 | Passed | 9 passed, editor test not applicable |
| Controls / legacy b5ac83d | Passed | 8 passed, editor and new cap tests not applicable |

NX2Apple source files were reconstructed from their `.upstream-ref` plus the ordered patch series. The existing Controls editor patch was hash-checked and applied before the existing workflow source edits. The complete final workflow's embedded patch steps, new tests and pre-existing English/UI source audit were executed against each reconstructed variant.

No game downloads, game code, keys, package extraction or actual builds were used in these tests. Synthetic settings profiles and mocked sensor sources are explicitly not gameplay validation.

## What was checked

- Whole source-set SHA-256 matching before any new patch writes; no mixing individual approved file hashes from different engine variants.
- All six duplicate patch applications rejected.
- All six source-tampering cases rejected without changing any files.
- Ten unittest cases per variant; 53 passed, 7 intentionally skipped as not applicable.
- Real generated settings tables: schema, dependencies, unique variable names, generic-vs-profile FPS rows, conflicting cap rejection and existing game/display pacing deduplication.
- Added C motion helper and extracted host bridge compiled with the host C compiler and a mock sensor harness.
- 1,000 heading/tilt combinations per variant: query does not mutate, heading resets, tilt is retained, rotation stays orthonormal with determinant +1, raw acceleration/gyro remain unchanged, degenerate/non-finite states are refused.
- Phone-source readiness, stale/off states, controller priority and modern history reset. Direct-controller priority checked on the NX2Apple variants that have that source.
- Extracted modern `mtl_fps_target()` compiled and exercised: explicit profile cap beats a stale generic 120 preference; Auto follows game pacing; non-cap profiles retain the generic target.
- Four control modes and nested menu labels retained; hold-only editor markers retained where applicable; no literal Han characters in the audited host source files.
- Full workflow YAML parsing, Bash syntax for every run block and embedded Python compilation.
- Structural comparison: only three new steps, pinned Actions/Standard ref and checkout credential options; all existing source-patch/build/download/Final Fantasy cleanup/upload steps otherwise unchanged.
- Repository patch tested by applying it to an exact clean snapshot: both workflow replacements and both document updates match the package, and `disk-test.yml` is deleted.

## What was NOT checked

- Full Objective-C/Swift/UIKit/Xcode compilation.
- A real GitHub Actions run, current runner availability or the installed Xcode application paths.
- Real device sensor behaviour, menu layout, controller interaction, performance, power, heat, game speed, saves or DLC gameplay.
- Broad compatibility of a 30 fps cap. The added cap is profile-limited and absent on legacy.
- New memory management or texture changes: none were made.

The CPU compiler test suppresses GCC's misleading-indentation warning for existing upstream single-line statements; other `-Wall -Wextra` diagnostics are errors. This is not a suppression of shader validation or the legacy resource audit.

## Audit copy usage

The patch script expects a clean engine source tree **after the original workflow's source edits**, not an arbitrary upstream checkout. It refuses unknown inputs or a second application.

On the corresponding prepared engine tree:

```sh
python /path/to/audit/pocket_updates.py
python /path/to/audit/test_pocket_updates.py
```

The normal workflows perform both steps automatically. Do not disable the guards to make an unrelated checkout pass.
