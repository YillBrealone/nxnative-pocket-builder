#!/usr/bin/env python3
"""Audited, source-hash-guarded Pocket Builder update. No packages/keys needed.
The identical script is embedded in both full workflows; this file is an audit copy.
"""
import hashlib
import json
import os
from pathlib import Path

# Filled from six locally reconstructed, post-existing-patch engine variants.
EXPECTED = {'controls-controls': {'dm/host/motion_fusion.h': 'caac0cc3a56ed28118fff165f2eb21ae266adf3ef1d7c99a7ff4134af22cb233', 'dm/host/hle_hid.c': 'f6e85720ede025da7a571993d299e128ae55730bcec33ea93d63396d858d6d9a', 'dm/games/settings.tsv': '409064858780547be0ab65ba4d4a92f27ee187258f788505d616261110b45424', 'dm/games/settings.py': '51fc8ea4d467bcce24b743509493871eec2096d925641fa88de91c211fc47ddd', 'dm/games/game.py': '1441727de2fb77e2a2bf4e7b36b5b3d55873001185577c619abe3c6c8622f9a3', 'dm/gfx/nvn/nvn_mtl.m': 'e4697f998a90692828595ac0d69e83346e6bce85194b4e293f9be883c869c32f', 'dm/ios/Sources/DmGamepad.m': '175e67aabdc5a1e3a1f0fff69813484331bcfdab9f37f2404ac79621f7c39519', 'dm/ios/Sources/front_ios.m': 'a35c456424613b1a3e104c3e2504e054107592d0a887cbb14159fb241f4864d0', 'dm/ios/Sources/LauncherSettings.swift': 'fe00f71f1a725ca13d8aad8b2dbbb2de4abad868ccb4d60eab57468296afcfa6', 'dm/ios/Sources/GameMenu.swift': '003dfc8af16f80837cc0ff5de08f51af23a9c3014831ec5b2cf420fa7aba37ab', 'dm/ios/Sources/DmGameMenu.h': 'b7a31b78cd56cc18011ddf6213ba5908a9bc05a31567dfe892eb7714852db854', 'dm/games/010093801237C000/game.tsv': '29aef510570f2415aea4679772a3c78128854d0f54436db99f93aa1e0c06cf4c'}, 'controls-legacy': {'dm/host/motion_fusion.h': '212e84f043636650a7ed8bfbc77acabf54ea618cdb160838225e28a72afec899', 'dm/host/hle_hid.c': '709b7ba3eaf1d4bdcf82e938ba8b3b702ba3a4e780fd19593f3a7490eb0e6f91', 'dm/games/settings.tsv': '5bfa86ddcee8fa2480e0ea1195524f01c612fbb25855d76ebab31fba6552a423', 'dm/games/settings.py': 'aad7af238515e8eb8fd35d1fcab140d81ce56fc9aa02dcc147769ff959bc8610', 'dm/games/game.py': 'a2556c87f247cf87c5a52d5f3ad8fd9c0dc7a8825284835f52adc49f3eec6af6', 'dm/gfx/nvn/nvn_mtl.m': 'ea93d742f0430fe4813a86f180ecc426bcc84b3a794b8b3472b35e565e99593d', 'dm/ios/Sources/DmGamepad.m': 'f30be8be70452871355475408b1d9709da8c83c267c51d4f7e61ad29c9b8e45a', 'dm/ios/Sources/front_ios.m': 'd5aa4e10b1d68254d9a759575d36d985a8f86913354da8563b2601b38641a1e3', 'dm/ios/Sources/LauncherSettings.swift': '405519743b22b54f21baf1dd78c5d6e6be6acd0297f4682e77b6f25e5ec8f38c'}, 'controls-standard': {'dm/host/motion_fusion.h': 'caac0cc3a56ed28118fff165f2eb21ae266adf3ef1d7c99a7ff4134af22cb233', 'dm/host/hle_hid.c': 'da32b1ef9628f40b2c237b315da9cb8140196e4a539bcbec39092696104b3e9b', 'dm/games/settings.tsv': '6ef411101f1d1fd8fe99eb70d38cd1b4efe5c4173f2e4cddbcce8fbe2e32178c', 'dm/games/settings.py': 'c2b410a6ef010b2ae84ecbc35ec52d8126b093d0db1ead2c2f5c85ffb64c8d86', 'dm/games/game.py': '3ac4daaa3042196c3817893cabc890a09be83475413d3f0943b27f5c9a201faf', 'dm/gfx/nvn/nvn_mtl.m': 'da9f4df61b0bca0caa4ece714edb9ec077cf8482c4d1f8e74a844a7528b02d5c', 'dm/ios/Sources/DmGamepad.m': '4aa30f7bf48e9e2e06dc775bf1fcf09e0ad8f8bb5696f852ba51191d9bd6011f', 'dm/ios/Sources/front_ios.m': '488aaae44615f4f292f4ef677639eb8c2dba4a8d87cc13ada4bacded48bda7a2', 'dm/ios/Sources/LauncherSettings.swift': 'bb6fd75c820ddfe5b962a81ed4f0607c4f2c1569f04736fd5f34f363c88f75ce', 'dm/ios/Sources/GameMenu.swift': '1093e2001ec127c52e952ccee5e343a6789dd6475e8807d40f03bb72ab06c0aa', 'dm/ios/Sources/DmGameMenu.h': '8ee198dc4d4a7c6845b72df8216959e8e9fbcf66798367d25b4e2a4173e5aa64', 'dm/games/010093801237C000/game.tsv': '29aef510570f2415aea4679772a3c78128854d0f54436db99f93aa1e0c06cf4c'}, 'main-legacy': {'dm/host/motion_fusion.h': '212e84f043636650a7ed8bfbc77acabf54ea618cdb160838225e28a72afec899', 'dm/host/hle_hid.c': '709b7ba3eaf1d4bdcf82e938ba8b3b702ba3a4e780fd19593f3a7490eb0e6f91', 'dm/games/settings.tsv': '5bfa86ddcee8fa2480e0ea1195524f01c612fbb25855d76ebab31fba6552a423', 'dm/games/settings.py': 'aad7af238515e8eb8fd35d1fcab140d81ce56fc9aa02dcc147769ff959bc8610', 'dm/games/game.py': 'a2556c87f247cf87c5a52d5f3ad8fd9c0dc7a8825284835f52adc49f3eec6af6', 'dm/gfx/nvn/nvn_mtl.m': 'ea93d742f0430fe4813a86f180ecc426bcc84b3a794b8b3472b35e565e99593d', 'dm/ios/Sources/DmGamepad.m': '3d69ff9c22013c6c425882285b759118cd0fbfc76801f31a672ad47150edee29', 'dm/ios/Sources/front_ios.m': 'd5aa4e10b1d68254d9a759575d36d985a8f86913354da8563b2601b38641a1e3', 'dm/ios/Sources/LauncherSettings.swift': '405519743b22b54f21baf1dd78c5d6e6be6acd0297f4682e77b6f25e5ec8f38c'}, 'main-main': {'dm/host/motion_fusion.h': 'caac0cc3a56ed28118fff165f2eb21ae266adf3ef1d7c99a7ff4134af22cb233', 'dm/host/hle_hid.c': 'f6e85720ede025da7a571993d299e128ae55730bcec33ea93d63396d858d6d9a', 'dm/games/settings.tsv': 'b79a4048f7ce9b70d37490c3cc66ede2636e607c68d3f7b956417ce01b16f6ec', 'dm/games/settings.py': '8be5079e8f93087ff43dabb89c79660e57d85541d9783193076805c02efa48f5', 'dm/games/game.py': '2af9b39c3b03462925801785812ecc5865fd7192a96a3278568c7447922f5d8a', 'dm/gfx/nvn/nvn_mtl.m': '4421878cba4491060f65c11af8d5c25980793152714aba8dafeb9c8f79987329', 'dm/ios/Sources/DmGamepad.m': '83ff227f57568b274ea7badf6b7b5b4edbc6cd2c46b735852c43ecc27d460263', 'dm/ios/Sources/front_ios.m': '333b762463597731e8bec9ac7ecab681e636c81f5f74bdadb3a8a585e5bff06b', 'dm/ios/Sources/LauncherSettings.swift': 'fe00f71f1a725ca13d8aad8b2dbbb2de4abad868ccb4d60eab57468296afcfa6', 'dm/ios/Sources/GameMenu.swift': '4e280f5354c9e3536aae751ec112459adafbfd68a89194c445ebf89beadd9910', 'dm/ios/Sources/DmGameMenu.h': 'ccceb3a8b14e056d7f301681b0b1fcdb553455e822c34343e44a0125bc9f6a9d', 'dm/games/010093801237C000/game.tsv': '29aef510570f2415aea4679772a3c78128854d0f54436db99f93aa1e0c06cf4c'}, 'main-standard': {'dm/host/motion_fusion.h': 'caac0cc3a56ed28118fff165f2eb21ae266adf3ef1d7c99a7ff4134af22cb233', 'dm/host/hle_hid.c': 'da32b1ef9628f40b2c237b315da9cb8140196e4a539bcbec39092696104b3e9b', 'dm/games/settings.tsv': '6ef411101f1d1fd8fe99eb70d38cd1b4efe5c4173f2e4cddbcce8fbe2e32178c', 'dm/games/settings.py': 'c2b410a6ef010b2ae84ecbc35ec52d8126b093d0db1ead2c2f5c85ffb64c8d86', 'dm/games/game.py': '3ac4daaa3042196c3817893cabc890a09be83475413d3f0943b27f5c9a201faf', 'dm/gfx/nvn/nvn_mtl.m': 'da9f4df61b0bca0caa4ece714edb9ec077cf8482c4d1f8e74a844a7528b02d5c', 'dm/ios/Sources/DmGamepad.m': '565b5084d17e8d48a0a78f113a25c709fc332f70eb8d7c22c962bb376dfb52b2', 'dm/ios/Sources/front_ios.m': '488aaae44615f4f292f4ef677639eb8c2dba4a8d87cc13ada4bacded48bda7a2', 'dm/ios/Sources/LauncherSettings.swift': 'bb6fd75c820ddfe5b962a81ed4f0607c4f2c1569f04736fd5f34f363c88f75ce', 'dm/ios/Sources/GameMenu.swift': 'e0166bdd456dc180a92475b78bb59278210a059ca9c8ba2f7c3a65f28ef156b0', 'dm/ios/Sources/DmGameMenu.h': '8ee198dc4d4a7c6845b72df8216959e8e9fbcf66798367d25b4e2a4173e5aa64', 'dm/games/010093801237C000/game.tsv': '29aef510570f2415aea4679772a3c78128854d0f54436db99f93aa1e0c06cf4c'}}  # GENERATED_MANIFEST


def once(text, old, new, label):
    if text.count(old) != 1:
        raise RuntimeError(f'{label}: expected exactly one source anchor, found {text.count(old)}')
    return text.replace(old, new, 1)


MOTION_HELPER = r'''
// Pocket Builder: zero phone heading without flattening its measured tilt.
// Rotation about world Z preserves gravity and the sensor's handedness.
static inline int pocket_motion_heading(motion_state *s, int apply) {
    if (!s->primed) return 0;
    for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++)
        if (!isfinite(s->R[i][j])) return 0;
    float x = s->R[0][0], y = s->R[1][0], n = hypotf(x, y);
    if (n < 1e-5f) return 0; // heading is ambiguous with this axis vertical
    if (!apply) return 1;
    float c = x / n, q = y / n;
    for (int j = 0; j < 3; j++) {
        float a = s->R[0][j], b = s->R[1][j];
        s->R[0][j] = c * a + q * b;
        s->R[1][j] = -q * a + c * b;
    }
    memset(s->angle, 0, sizeof s->angle);
    return 1;
}
'''

MOTION_HOST = r'''
// Pocket Builder: phone only; never take control away from a live controller.
// No new sensor queue, gyro mapping or controller-source policy is installed.
bool dm_pocket_phone_recenter(bool apply) {
    pthread_once(&g_motion_once, motion_env);
    if (g_motion_off || !g_phone_mode) return false;
    if (g_phone_mode < 0) {
        uint32_t sources = 1u | merged_players();
        for (int i = 0; i < DM_PLAYERS; i++) if (sources >> i & 1) {
            motion_state ignored;
            if (motion_copy(&g_motion[i], &ignored) || motion_copy(&g_hid_motion[i], &ignored)) return false;
        }
    }
    live_motion *m = &g_phone_motion;
    pthread_mutex_lock(&m->mu);
    bool ready = m->last_ns && now_ns() - m->received_ns <= MOTION_STALE_NS;
    bool ok = ready && pocket_motion_heading(&m->st, apply);
    POCKET_RING_RESET
    pthread_mutex_unlock(&m->mu);
    return ok;
}
'''

OBJC_FIXED = r'''
// Respect only explicit engine-recorded overrides, not ordinary saved choices.
static BOOL pocket_setting_fixed(NSString *env) {
    for (NSString *name in @[@"DM_ENV_FILE_KEYS", @"DM_ENV_LAUNCH_KEYS"]) {
        const char *raw = getenv(name.UTF8String);
        if (!raw) continue;
        NSArray<NSString *> *keys = [[NSString stringWithUTF8String:raw] componentsSeparatedByCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if ([keys containsObject:env]) return YES;
    }
    return NO;
}
'''

OBJC_DEPENDENCY = r'''
        // A dependency naming an absent setting remains visible, as in LauncherModel.
        NSString *need = [s[@"needs"] isKindOfClass:NSString.class] ? s[@"needs"] : nil;
        NSRange eq = [need rangeOfString:@"="];
        if (need.length && eq.location != NSNotFound) {
            NSString *key = [need substringToIndex:eq.location], *want = [need substringFromIndex:eq.location + 1];
            for (NSDictionary *parent in settings) {
                if (![parent isKindOfClass:NSDictionary.class]) continue;
                if ([parent[@"env"] isEqualToString:key]) {
                    if (![[self currentSettingValue:key def:parent[@"default"] ?: @""] isEqualToString:want]) kind = @"hidden";
                    break;
                }
            }
            if ([kind isEqualToString:@"hidden"]) continue;
        }
'''


def make_changes(root):
    paths = [
        'dm/host/motion_fusion.h', 'dm/host/hle_hid.c',
        'dm/games/settings.tsv', 'dm/games/settings.py', 'dm/games/game.py',
        'dm/gfx/nvn/nvn_mtl.m', 'dm/ios/Sources/DmGamepad.m',
        'dm/ios/Sources/front_ios.m', 'dm/ios/Sources/LauncherSettings.swift',
    ]
    modern = (root / 'dm/ios/Sources/GameMenu.swift').is_file()
    if modern:
        paths += ['dm/ios/Sources/GameMenu.swift', 'dm/ios/Sources/DmGameMenu.h',
                  'dm/games/010093801237C000/game.tsv']
    original = {p: (root / p).read_text(encoding='utf-8') for p in paths}
    # Match one complete audited variant, not independent hashes from mixed engines.
    actual = {p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in paths}
    matches = [name for name, hashes in EXPECTED.items() if hashes == actual]
    if not matches:
        raise RuntimeError('Pocket update: source set does not match an audited engine/workflow. '
                           'Unknown changes or a repeated patch; refusing to modify sources.')
    result = dict(original)
    fusion = 'dm/host/motion_fusion.h'
    result[fusion] += MOTION_HELPER
    hid = 'dm/host/hle_hid.c'
    marker = 'static int motion_live(int p, motion_state *out) {'
    ring = 'if (ok && apply) { m->count = 0; m->head = 0; }' if 'motion_sample ring[LIVE_RING]' in original[hid] else '(void)apply;'
    bridge = MOTION_HOST.replace('POCKET_RING_RESET', ring)
    if 'static live_motion g_direct_motion[' in original[hid]:
        bridge = bridge.replace('if (motion_copy(&g_motion[i], &ignored) || motion_copy(&g_hid_motion[i], &ignored)) return false;',
                                'if (motion_copy(&g_motion[i], &ignored) || motion_copy(&g_hid_motion[i], &ignored) || motion_copy(&g_direct_motion[i], &ignored)) return false;')
    result[hid] = once(original[hid], marker, bridge + '\n' + marker, 'motion host bridge')
    p = 'dm/ios/Sources/LauncherSettings.swift'
    result[p] = once(original[p], '        fixed = []',
        '        fixed = fromLaunch.union((env["DM_ENV_FILE_KEYS"] ?? "").split(separator: " ").map(String.init))',
        'explicit override policy (ordinary defaults and saved choices stay editable)')

    # Capability-limited Auto/30: only the profiled title from the reference fork.
    # Legacy renderer has additional frame-limit policies: do not change those here.
    game = 'dm/games/game.py'
    g = original[game]
    anchor = "    fh = g.get('fps_hold', 'on')"
    decl = "    fc = g.get('fps_cap', '0')\n    if fc not in ('0', '1') or (fc == '1' and ft != '0'):\n        sys.exit(f'{g.id}: invalid/conflicting fps_cap')\n"
    g = once(g, anchor, decl + anchor, 'fps capability validation')
    has_interval = '\nDM_PRESENT_INTERVAL\t' in original['dm/games/settings.tsv']
    anchor = "         f'#define DM_GAME_FPS_TARGET {int(ft)}',"
    additions = "\n         f'#define DM_GAME_FPS_CAP {int(fc)}',\n         f'#define DM_GAME_POCKET_FPS_ROW {int(fc == \"0\"" + (' and not (pi == "display" and ft == "0")' if has_interval else '') + ")}',"
    g = once(g, anchor, anchor + additions, 'fps capability macros')
    result[game] = g
    if modern:
        p = 'dm/games/010093801237C000/game.tsv'
        if '\nfps_cap\t' in original[p]:
            raise RuntimeError('Profile already has a cap policy; review before porting')
        result[p] += '\n# Pocket Builder: upstream no-bc reports normal speed with Auto/30; device validation still required.\nfps_cap\t1\n'
        p = 'dm/gfx/nvn/nvn_mtl.m'
        # Existing generic 30/60/120 remains for every other game. For fps_cap games,
        # avoid a stale saved generic target taking precedence over Auto/30.
        anchor = 'int mtl_fps_target(void) {'
        block = '''
    if (DM_GAME_FPS_CAP) {
        // A saved change applies on the next app launch, as the menu states.
        static _Atomic int pocket_cap = -1;
        int pc = atomic_load(&pocket_cap);
        if (pc < 0) {
            const char *value = getenv("DM_FPS");
            pc = value && !strcmp(value, "30") ? 30 : 0;
            atomic_store(&pocket_cap, pc);
        }
        if (pc == 30) return 30;
        int pf = nvn_game_fps();
        return pf == 30 || pf == 120 ? pf : 60;
    }
'''
        result[p] = once(original[p], anchor, anchor + block, 'profile-aware fps routing')
    rows = []
    for line in original['dm/games/settings.tsv'].splitlines():
        if line.startswith('DM_FPS_TARGET\t'):
            parts = line.split('\t'); parts += [''] * max(0, 9-len(parts))
            parts[4] = 'DM_GAME_POCKET_FPS_ROW==1'
            parts[7] = 'Higher targets do not guarantee higher performance. Game speed and heat need device testing.'
            line = '\t'.join(parts)
        if line.startswith('DM_PRESENT_INTERVAL\t'):
            parts=line.split('\t'); parts += [''] * max(0, 9-len(parts)); parts[7]='Uses the profile\'s game/display pacing. 30 fps is the lower-power choice; applies next launch.'; line='\t'.join(parts)
        rows.append(line)
    if not any(x.startswith('DM_MOTION\t') for x in rows):
        rows.append('DM_MOTION\ttoggle\t-\t1\tplatform:ios\tControls\tMotion controls\tTilt and gyro input; applies next launch. Phone shake input remains separate.')
    if modern:
        if any(x.startswith('DM_FPS\t') for x in rows):raise RuntimeError('DM_FPS already has a settings row')
        rows.append('DM_FPS\tchoice\t0=Auto,30=30 fps (Lower power)\t0\tDM_GAME_FPS_CAP==1\tPerformance\tFrame rate\tAuto follows the game. Experimental 30 fps option for this profile; restart to apply.\tlevel=basic')
    result['dm/games/settings.tsv'] = '\n'.join(rows)+'\n'

    if modern:
        p='dm/ios/Sources/DmGameMenu.h'
        result[p] = original[p] + '\n// Pocket Builder: query readiness or recenter the active phone stream.\nbool dm_pocket_phone_recenter(bool apply);\n'
        p='dm/ios/Sources/GameMenu.swift';s=original[p]
        s=once(s, '    other.append(UIAction(title: "More Settings & Cloud Saves…"', '''    controls.append(UIAction(title: "Recenter Phone Motion", attributes: dm_pocket_phone_recenter(false) ? [] : .disabled) { _ in
        _ = dm_pocket_phone_recenter(true)
    })
    other.append(UIAction(title: "More Settings & Cloud Saves…"''', 'Swift recenter action')
        s=once(s, '    func pick(_ v: String) { m.choose(s, v); _ = dm_setting_live(s.env, v) }', '    func pick(_ v: String) { guard !fixed else { return }; m.choose(s, v); _ = dm_setting_live(s.env, v) }', 'Swift fixed action guard')
        s=once(s, '        if fixed { a.subtitle = "Set in env.txt" }', '        a.subtitle = fixed ? "Set by environment override" : (s.note.isEmpty ? nil : s.note)', 'Swift setting note')
        if 'children: rActs)' in s:
            s=once(s, 'return UIMenu(title: menuLabel, options: .singleSelection, children: rActs)', 'return UIMenu(title: menuLabel, subtitle: fixed ? "Set by environment override" : (s.note.isEmpty ? nil : s.note), options: .singleSelection, children: rActs)', 'Swift range note')
        elif 'let options = offeredOptions(s, current: now)' not in s:
            raise RuntimeError('Unknown Swift range renderer')
        s=once(s, 'subtitle: fixed ? "\\(current), set in env.txt" : nil, options: .singleSelection, children: actions)', 'subtitle: fixed ? "\\(current), set by environment override" : (s.note.isEmpty ? nil : s.note), options: .singleSelection, children: actions)', 'Swift choice note')
        result[p]=s
    else:
        p='dm/ios/Sources/DmGamepad.m';s=original[p]
        s=once(s, '#import <UIKit/UIKit.h>', '#import <UIKit/UIKit.h>\n#include <stdbool.h>\n#include <stdlib.h>\nextern bool dm_pocket_phone_recenter(bool apply);\n'+OBJC_FIXED, 'Objective-C declarations')
        s=once(s, '    NSString *now = [self currentSettingValue:env def:def];', '    NSString *now = [self currentSettingValue:env def:def];\n    BOOL fixed = pocket_setting_fixed(env);', 'Objective-C fixed state')
        s=once(s, '        act.state = isOn ?', '        if (fixed) { act.attributes = UIMenuElementAttributesDisabled; act.subtitle = @"Set by environment override"; }\n        act.state = isOn ?', 'Objective-C fixed toggle')
        s=once(s, '        act.state = sel ?', '        if (fixed) act.attributes = UIMenuElementAttributesDisabled;\n        act.state = sel ?', 'Objective-C fixed choice')
        s=once(s, '        [seen addObject:env];', OBJC_DEPENDENCY+'\n        [seen addObject:env];', 'Objective-C dependencies')
        s=once(s, '        if (!el) continue;', '''        if (!el) continue;
        NSString *note = [s[@"note"] isKindOfClass:NSString.class] ? s[@"note"] : @"";
        NSString *detail = pocket_setting_fixed(env) ? @"Set by environment override" : (note.length ? note : nil);
        if ([el isKindOfClass:UIAction.class]) ((UIAction *)el).subtitle = detail;
        else if ([el isKindOfClass:UIMenu.class]) ((UIMenu *)el).subtitle = detail;''', 'Objective-C notes')
        s=once(s, '    UIAction *openSheet = [UIAction actionWithTitle:@"More Settings & Cloud Saves…"', '''    UIAction *recenter = [UIAction actionWithTitle:@"Recenter Phone Motion" image:nil identifier:nil handler:^(__kindof UIAction *a) {
        (void)a; (void)dm_pocket_phone_recenter(true);
    }];
    if (!dm_pocket_phone_recenter(false)) recenter.attributes = UIMenuElementAttributesDisabled;
    [ctrlRows addObject:recenter];
    UIAction *openSheet = [UIAction actionWithTitle:@"More Settings & Cloud Saves…"''', 'Objective-C recenter action')
        result[p]=s
        p='dm/ios/Sources/front_ios.m';s=original[p]
        s=once(s, 'void dm_apply_setting_live(const char *env, const char *value) {', OBJC_FIXED+'\nvoid dm_apply_setting_live(const char *env, const char *value) {', 'Objective-C fixed helper')
        s=once(s, '    if (!env || !value) return;', '    if (!env || !value || pocket_setting_fixed([NSString stringWithUTF8String:env])) return;', 'Objective-C fixed guard')
        result[p]=s

    for p,text in result.items():
        if p.endswith('.py'):compile(text,p,'exec')
    # Do not edit files that this update only reads/guards.
    return matches, {p: s for p,s in result.items() if s != original[p]}


def apply(root):
    matches, changes = make_changes(root)
    # All anchors and input hashes checked before the first write.
    for p, text in changes.items():
        (root / p).write_text(text, encoding='utf-8')
    print('Pocket update applied:', ', '.join(matches), ';', len(changes), 'files')
    summary = os.environ.get('GITHUB_STEP_SUMMARY')
    if summary:
        with open(summary, 'a', encoding='utf-8') as f:
            f.write('## Pocket settings and motion update\n'
                    '- Audited source set: ' + ', '.join(matches) + '.\n'
                    '- Settings notes/dependencies and override guards; phone-heading recenter action.\n'
                    '- Auto/30 is profile-limited on modern engines; legacy pacing unchanged.\n'
                    '- Source checks are not Xcode or device/gameplay validation.\n\n')


if __name__ == '__main__':
    apply(Path.cwd())
