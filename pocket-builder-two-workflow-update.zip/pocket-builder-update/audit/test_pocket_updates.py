#!/usr/bin/env python3
"""Run on an engine AFTER its original workflow patches and pocket update.
CPU-only checks: no game dumps, keys, GPU or network. Not a UIKit/device test.
"""
import importlib.util
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest

ROOT = Path.cwd()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


class PocketChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.modern = (ROOT/'dm/ios/Sources/GameMenu.swift').exists()
        cls.game = load_module('game', ROOT/'dm/games/game.py')
        sys.modules['game'] = cls.game
        sys.path.insert(0, str(ROOT/'dm/tools'))
        cls.settings = load_module('pocket_settings', ROOT/'dm/games/settings.py')

    def test_setting_schema(self):
        rows = list(self.settings.rows())
        names = [row[1][0] for row in rows]
        self.assertEqual(len(names), len(set(names)))
        self.assertIn('DM_MOTION', names)
        self.assertEqual('DM_FPS' in names, self.modern)
        for number, columns in rows:
            self.settings.meta(columns[8], number)

    def build_settings(self, *, cap=False, target='0', display=False):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'0100000000000000';p.mkdir()
            p.joinpath('game.tsv').write_text('name\tSynthetic settings test\ntitle_id\t0100000000000000\nprogram_id\t0100000000000000\nmodules\tmain\nromfs_marker\tsynthetic\nmem_reserve\t0x100000\nmem_alias\t0x1000\nmem_stack\t0x1000\napp_pool\t0x10000\n'
                +'fps_target\t'+target+'\nfps_cap\t'+str(int(cap))+'\npresent_interval\t'+('display' if display else 'game')+'\n')
            old={k:os.environ.get(k) for k in ('GFXAPI','SETTINGS_PLATFORM')}
            os.environ.update(GFXAPI='nvn',SETTINGS_PLATFORM='ios')
            try:return self.settings.build(str(p), tmp, str(Path(tmp)/'missing.nacp'))['settings']
            finally:
                for k,v in old.items():
                    if v is None:os.environ.pop(k,None)
                    else:os.environ[k]=v

    def test_no_global_low_power_cap(self):
        rows=self.build_settings()
        self.assertNotIn('DM_FPS',[r['env'] for r in rows])
        self.assertIn('DM_FPS_TARGET',[r['env'] for r in rows])

    def test_profile_cap_has_one_fps_control(self):
        if not self.modern:self.skipTest('legacy frame policy intentionally unchanged')
        rows=self.build_settings(cap=True)
        fps=[r for r in rows if r['env'] in ('DM_FPS','DM_FPS_TARGET','DM_PRESENT_INTERVAL')]
        self.assertEqual([r['env'] for r in fps],['DM_FPS'])
        self.assertEqual(fps[0]['default'],'0')
        self.assertEqual([o[0] for o in fps[0]['options']],['0','30'])

    def test_present_interval_deduplicates(self):
        rows=self.build_settings(display=True)
        fps=[r['env'] for r in rows if r['env'] in ('DM_FPS','DM_FPS_TARGET','DM_PRESENT_INTERVAL')]
        has_interval='\nDM_PRESENT_INTERVAL\t' in (ROOT/'dm/games/settings.tsv').read_text()
        self.assertEqual(fps,['DM_PRESENT_INTERVAL' if has_interval else 'DM_FPS_TARGET'])

    def test_conflicting_cap_refused(self):
        with self.assertRaises(SystemExit):self.build_settings(cap=True,target='60')

    def test_four_modes_and_groups_preserved(self):
        p=ROOT/'dm/ios/Sources'/('GameMenu.swift' if self.modern else 'DmGamepad.m')
        s=p.read_text()
        for label in ('2D Controls (Simple)','3D Controls (Full)','Tap (Touchscreen)','Trackpad (Drag & Tap)',
                      'Control Mode','Display','Controls','Performance','Other Settings','Next launch','Recenter Phone Motion'):
            self.assertIn(label,s)
        if self.modern:
            self.assertIn('m.rows(in: section)',s)
            self.assertIn('guard !fixed else { return }',s)
            self.assertIn('s.note.isEmpty',s)
        else:
            for token in ('s[@"needs"]','s[@"note"]','pocket_setting_fixed','UIMenuElementAttributesDisabled'):
                self.assertIn(token,s)
            self.assertIn('!value || pocket_setting_fixed',(ROOT/'dm/ios/Sources/front_ios.m').read_text())

    def test_editor_stays_hold_only(self):
        s=(ROOT/'dm/ios/Sources/DmGamepad.m').read_text()
        if 'edit_one_line' not in s:self.skipTest('no advanced editor on this path')
        self.assertIn('initWithItems:@[@"Hold"]',s)
        self.assertNotIn('initWithItems:@[@"Hold", @"Toggle", @"Turbo"]',s)
        self.assertIn('m->mode = DM_PAD_MACRO_HOLD;',s)

    def test_explicit_overrides_not_defaults_are_locked(self):
        s=(ROOT/'dm/ios/Sources/LauncherSettings.swift').read_text()
        self.assertNotIn('fixed = []',s)
        self.assertIn('fixed = fromLaunch.union((env["DM_ENV_FILE_KEYS"]',s)
        self.assertIn('s.accepts',s)

    def test_english_source(self):
        for p in (ROOT/'dm/ios/Sources').rglob('*'):
            if p.is_file() and p.suffix in ('.m','.mm','.h','.swift'):
                self.assertIsNone(re.search(r'[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]',p.read_text()),str(p))

    def test_cpu_motion_and_fps(self):
        hid=(ROOT/'dm/host/hle_hid.c').read_text()
        start=hid.index('bool dm_pocket_phone_recenter(bool apply) {')
        end=hid.index('\nstatic int motion_live',start)
        bridge=hid[start:end]
        ring='motion_sample ring[LIVE_RING]' in hid
        src=r'''
#include <assert.h>
#include <stdbool.h>
#include <stdatomic.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "motion_fusion.h"
#define DM_PLAYERS 2
#define MOTION_STALE_NS 300000000
static uint64_t clock_value = 1000000000;
static uint64_t now_ns(void) { return clock_value; }
static uint32_t merged_players(void) { return 0; }
typedef struct { pthread_mutex_t mu; motion_state st; uint64_t last_ns, received_ns; unsigned count, head; } live_motion;
static live_motion g_phone_motion = {.mu=PTHREAD_MUTEX_INITIALIZER};
static live_motion g_motion[DM_PLAYERS] = {{.mu=PTHREAD_MUTEX_INITIALIZER},{.mu=PTHREAD_MUTEX_INITIALIZER}};
static live_motion g_hid_motion[DM_PLAYERS] = {{.mu=PTHREAD_MUTEX_INITIALIZER},{.mu=PTHREAD_MUTEX_INITIALIZER}};
static int g_motion_off, g_phone_mode = -1;
static pthread_once_t g_motion_once = PTHREAD_ONCE_INIT;
static void motion_env(void) {}
static uint64_t motion_copy(live_motion *m, motion_state *out) {
    pthread_mutex_lock(&m->mu);
    uint64_t t=m->last_ns && now_ns()-m->received_ns <= MOTION_STALE_NS ? m->last_ns : 0;
    if(t) *out=m->st;
    pthread_mutex_unlock(&m->mu); return t;
}
BRIDGE
FPS_FUNCTION
static int near(float a,float b) { return fabsf(a-b)<0.0001f; }
int main(int argc, char **argv) {
    (void)argc; (void)argv;
    motion_state s; motion_reset(&s);
    assert(!pocket_motion_heading(&s,0));
    for(int k=0;k<1000;k++) {
        float yaw=k*0.017f, tilt=(k%100-50)*0.01f;
        float c=cosf(yaw), q=sinf(yaw), a=cosf(tilt), b=sinf(tilt);
        s=(motion_state){.R={{c*a,-q,c*b},{q*a,c,q*b},{-b,0,a}},.primed=1,.acc={0,0,-1},.gyro={1,2,3},.angle={4,5,6}};
        motion_state before=s;
        assert(pocket_motion_heading(&s,0));assert(!memcmp(&s,&before,sizeof s));
        assert(pocket_motion_heading(&s,1));assert(near(s.R[1][0],0));
        for(int j=0;j<3;j++) { assert(near(s.R[2][j],before.R[2][j]));assert(s.angle[j]==0);assert(s.acc[j]==before.acc[j]);assert(s.gyro[j]==before.gyro[j]); }
        for(int i=0;i<3;i++) for(int j=0;j<3;j++) { float dot=0;for(int n=0;n<3;n++)dot+=s.R[n][i]*s.R[n][j];assert(near(dot,i==j?1:0)); }
        float det=s.R[0][0]*(s.R[1][1]*s.R[2][2]-s.R[1][2]*s.R[2][1])-s.R[0][1]*(s.R[1][0]*s.R[2][2]-s.R[1][2]*s.R[2][0])+s.R[0][2]*(s.R[1][0]*s.R[2][1]-s.R[1][1]*s.R[2][0]);assert(near(det,1));
    }
    s.R[0][0]=s.R[1][0]=0;assert(!pocket_motion_heading(&s,1));
    s.R[0][0]=NAN;assert(!pocket_motion_heading(&s,1));
    assert(!dm_pocket_phone_recenter(false));
    motion_reset(&g_phone_motion.st);g_phone_motion.st.primed=1;
    g_phone_motion.last_ns=g_phone_motion.received_ns=now_ns();
    g_phone_motion.count=10;g_phone_motion.head=4;
    assert(dm_pocket_phone_recenter(false));assert(g_phone_motion.count==10);
    g_motion_off=1;assert(!dm_pocket_phone_recenter(true));g_motion_off=0;
    g_phone_mode=0;assert(!dm_pocket_phone_recenter(true));g_phone_mode=-1;
    g_motion[0].last_ns=g_motion[0].received_ns=now_ns();assert(!dm_pocket_phone_recenter(true));
    g_motion[0].last_ns=0;
    g_hid_motion[0].last_ns=g_hid_motion[0].received_ns=now_ns();assert(!dm_pocket_phone_recenter(true));
    g_hid_motion[0].last_ns=0;
    assert(dm_pocket_phone_recenter(true));RING_ASSERT
    clock_value+=MOTION_STALE_NS+1;assert(!dm_pocket_phone_recenter(true));
    FPS_ASSERT
    puts("CPU motion invariants, source gating and FPS precedence passed");return 0;
}
'''
        fps_function='';fps_assert=''
        if self.modern:
            text=(ROOT/'dm/gfx/nvn/nvn_mtl.m').read_text()
            st=text.index('int mtl_fps_target(void) {');depth=0;endfn=None
            for n in range(text.index('{',st),len(text)):
                if text[n]=='{':depth+=1
                elif text[n]=='}':
                    depth-=1
                    if not depth:endfn=n+1;break
            fps_function='#define MLOG(...) ((void)0)\nstatic int cap=1, game_fps=60;\n#define DM_GAME_FPS_CAP cap\nstatic int nvn_game_fps(void) {return game_fps;}\n'+text[st:endfn]
            fps_assert='setenv("DM_FPS_TARGET","120",1);int low=argc>1 && !strcmp(argv[1],"30");setenv("DM_FPS",low?"30":"0",1);assert(mtl_fps_target()==(low?30:60));setenv("DM_FPS",low?"0":"30",1);assert(mtl_fps_target()==(low?30:60));game_fps=30;assert(mtl_fps_target()==30);cap=0;assert(mtl_fps_target()==120);'
        if 'g_direct_motion[i]' in bridge:
            src=src.replace('static int g_motion_off,', 'static live_motion g_direct_motion[DM_PLAYERS] = {{.mu=PTHREAD_MUTEX_INITIALIZER},{.mu=PTHREAD_MUTEX_INITIALIZER}};\nstatic int g_motion_off,')
            src=src.replace('g_hid_motion[0].last_ns=0;', 'g_hid_motion[0].last_ns=0;\ng_direct_motion[0].last_ns=g_direct_motion[0].received_ns=now_ns();assert(!dm_pocket_phone_recenter(true));g_direct_motion[0].last_ns=0;')
        src=src.replace('BRIDGE',bridge).replace('FPS_FUNCTION',fps_function).replace('FPS_ASSERT',fps_assert).replace('RING_ASSERT','assert(g_phone_motion.count==0 && g_phone_motion.head==0);' if ring else 'assert(g_phone_motion.count==10);')
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'test.c';f.write_text(src)
            binary=Path(tmp)/'test'
            subprocess.run(['cc','-std=gnu11','-Wall','-Wextra','-Werror','-Wno-misleading-indentation','-I'+str(ROOT/'dm/host'),str(f),'-o',str(binary),'-lm','-pthread'],check=True)
            subprocess.run([str(binary),'auto'],check=True)
            if self.modern:subprocess.run([str(binary),'30'],check=True)


if __name__=='__main__':
    unittest.main(argv=[sys.argv[0]],verbosity=2)
